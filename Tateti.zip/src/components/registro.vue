<template>
<div>
    <div><h2>Enter Name Player 1</h2><input class="input" type="text" placeholder="Nombre Player 1"></div>
    <div><h2>Enter Name Player 2</h2><input class="input" type="text" placeholder="Nombre Player 2"></div>
</div>
</template>

<script>
export default {
}
</script>

<style>

</style>
